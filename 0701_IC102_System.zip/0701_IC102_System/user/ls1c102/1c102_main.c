
// ================================================ 电源接线 ================================================ //
//   VCC         接          DC 5V/3.3V      // OLED 屏电源正
//   GND         接          GND             // OLED 屏电源地
// ================================================ 液晶屏数据线接线 ================================================ //
// 本模块默认数据总线类型为4线制SPI
//   OLED 模块
//   D0          接          GPIO53          // OLED 屏 SPI 时钟信号           // 硬件 SPI CLK
//   D1/MOSI     接          GPIO55          // OLED 屏 SPI 写信号             // 硬件 SPI MOSI
//   CS          接          GPIO56          // OLED 屏片选控制信号            // 硬件 SPI CSN0
//   RES         接          GPIO40          // OLED 屏复位控制信号。          // 普通 GPIO
//   DC          接          GPIO01          // OLED 屏数据/命令选择控制信号   // 普通 GPIO
//${workspaceFolder}/drivers/private/ls1c102/

#include "ls1x.h"
#include "Config.h"
#include "oled.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_i2c.h"
#include "SHT30.h"
#include "ls1x_string.h"
#include "ls1x_uart.h"
#include "ls1c102_ptimer.h"
#include "1c102_Interrupt.h"
#include "queue.h"
#include "espwifi.h"
#include "ls1c102_adc.h"
#include "ls1x_printf.h"

#define LED1 GPIO_PIN_22
#define LED2 GPIO_PIN_24

uint8_t Read_Buffer[DATA_LEN];//设置接收缓冲数组
uint8_t Read_length;

extern uchar_t SHT30_Temp[6],SHT30_Humi[6];
uint16_t illumvalue=0;
uchar_t Illustr[6]; //存放光照值的字符串

static int strncmp(const char *s1, const char *s2, size_t n)
{
    if (n == 0)
        return 0;

    while (n-- != 0 && *s1 == *s2)
    {
        if (n == 0 || *s1 == '\0')
            break;
        s1++;
        s2++;
    }

    return (*(unsigned char *) s1) - (*(unsigned char *) s2);
}

int main(int arg, char *args[])
{   uchar_t Illustr_len;

    Uart0_init(115200);
    espwifi_init();
    printf("ready!\r\n");
    // gpio_write_pin(LED1,1);
    // gpio_write_pin(LED2,1);

    Spi_Init(SPI_DIV_2);
    OLED_Init();// 初始化 OLED 模块
    OLED_Clear();// OLED 清屏
    printf("OLED ok!\r\n");

    OLED_ShowCHinese( 0, 0, 0); //温
    OLED_ShowCHinese( 16, 0, 1); //度
    OLED_ShowChar(32, 0, ':', 16); //：
    OLED_ShowCHinese(0, 16, 2); //湿
    OLED_ShowCHinese( 16, 16, 1); //度
    OLED_ShowChar(32, 16, ':', 16); //：
    OLED_ShowCHinese(0, 32, 3); //光
    OLED_ShowCHinese(16, 32, 4); //照
    OLED_ShowChar(32, 32, ':', 16); //：
    printf("OLED display ok!\r\n");

    IIC_Init();   
    delay_ms(10);
    printf("IIC_Init ok!\r\n");
	sht30_init();//初始化SHT30 
	delay_ms(10);
    printf("sht30 ok!\r\n");

    
    Adc_powerOn();//adc电源开启
    //Adc_open(ADC_CHANNEL_I0);//打开通道0
    Adc_open(ADC_CHANNEL_I4);//打开通道0

    while (1)
    {
        sht30_data_process();
        delay_ms(20);   
        
        illumvalue=Adc_Measure(ADC_CHANNEL_I4);
        sprintf(Illustr,"%d",illumvalue);
        printf("\r\nIllumination:%s\r\n",Illustr);       
        
        publish_message_to_bafayun();
        delay_ms(50);
       
        // if (Queue_isEmpty(&Circular_queue) == 0)//判断队列是否为空，即判断是否收到数据
        // {
        //     Read_length = Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        //     memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
        //     Queue_Read(&Circular_queue, Read_Buffer, Read_length);//读取队列缓冲区的值到接收缓冲区
        //     Read_Buffer[Read_length] = '\0';//字符串接收结束符
        //     printf("receive commond:%s\r\n", Read_Buffer);// 打印接收内容
        //     /*
        //        gpio_22外接LED灯
        //        判断收到字符为 ON  点灯
        //        判断收到字符为 OFF 关灯
        //     */
        //     if (strncmp((const char *)Read_Buffer, "#-01-ON", 7) == 0 )
        //     {
        //         gpio_write_pin(LED1, 0);
        //         printf("LED1 is ON!\r\n");
        //     }
        //     else if (strncmp((const char *)Read_Buffer, "#-01-OFF", 8) == 0) 
        //     {
        //         gpio_write_pin(LED1, 1);
        //         printf("LED1 is OFF!\r\n");
        //     }
        //     else if (strncmp((const char *)Read_Buffer, "#-02-ON", 7) == 0)
        //     {
        //         gpio_write_pin(LED2, 0);
        //         printf("LED2 is ON!\r\n");
        //     }
        //     else if (strncmp((const char *)Read_Buffer, "#-02-OFF", 8) == 0) 
        //     {
        //         gpio_write_pin(LED2, 1);
        //         printf("LED2 is OFF!\r\n");
        //     }
        // }
       
        OLED_ShowString(40, 0,SHT30_Temp); //显示温度
        OLED_ShowCHinese( 80, 0, 5); //摄氏度        
        OLED_ShowString(40, 16,SHT30_Humi);//显示湿度
        OLED_ShowChar(80, 16, '%', 16);     
        
        Illustr_len=strlen(Illustr);
        if(Illustr_len==3)
        {          
          OLED_ShowString(40, 32,Illustr); //显示光照值
          OLED_ShowChar(64, 32, ' ', 16);
        }
        else
          OLED_ShowString(40, 32,Illustr); //显示光照值
        delay_ms(2000);
        // //delay_ms(500);//处理数据时间大于发送数据，限制循环执行速率

    }
    return 0;
}

