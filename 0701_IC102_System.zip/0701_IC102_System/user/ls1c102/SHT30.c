#include "SHT30.h"
#include "ls1c102_i2c.h"
#include "ls1x_latimer.h"
#include "Config.h"
#include "ls1x_printf.h"

uchar_t read_sht_data[7];//数据读取缓存


uint16_t SHT30_temperature;
uint16_t SHT30_humidity;
uchar_t SHT30_Temp[6],SHT30_Humi[6];
uchar_t SHT30_Temp1[5],SHT30_Humi1[5];


/*****SHT30初始化*******/
void sht30_init(void)
{	
	IIC_Start();                //启动总线
	IIC_Send_Byte(0x88);      //发送从器件写地址 
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA
	IIC_Send_Byte(0x20);       //low Repeatability,0.5mps
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA ;
	IIC_Send_Byte(0x32);       //low Repeatability,0.5mps
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA ;
	IIC_Stop();
	delay_ms(150);              //延时测量数据，为下一步读取做准备
}

/*****SHT30读数据*******/
void read_sht30(uchar_t *p,uchar_t number)
{
	IIC_Start();                //启动总线
	IIC_Send_Byte(0x88);      //发送从器件写地址 
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA
	IIC_Send_Byte(0xe0);       //数据获取命令
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA ;
	IIC_Send_Byte(0x00);       //数据获取命令
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA ;

	IIC_Start();                //启动总线
	IIC_Send_Byte(0x89);      //发送从器件读地址 
	IIC_Wait_Ack();            //器件应答检测	此函数已设F0=SDA
          do
		  {
		    *p=IIC_Read_Byte1();	 //开始逐个读出字节
			p++;
			if(number!=1)
			  IIC_Ack();			 //应答
		  }
		  while(--number);       //直至读完数据
		  IIC_NAck();             //总线非应答
	IIC_Stop();			
}

/**********CRC数据校验**********/
int  crc8_compute(uchar_t *check_data, uchar_t num_of_data)
{
 	uchar_t i;        // bit mask
    uchar_t crc = 0xFF; // calculated checksum
    uchar_t byteCtr;    // byte counter

 // calculates 8-Bit checksum with given polynomial
    for(byteCtr = 0; byteCtr < num_of_data; byteCtr++) 
	{
     crc ^= (check_data[byteCtr]);//异或赋值，crc=crc^(check_data[byteCtr])
		
 	//crc校验，最高位是1就^0x31
     for(i = 8; i > 0; --i) 
		{
         if(crc & 0x80) 
			{
             crc = (crc << 1) ^ 0x31;
            }  
		 else 
			{
             crc = (crc << 1);
            }
        }
    }
 return crc;
}

/********CRC数据校验缓冲***************/
int sht30_crc8_check(uchar_t *p,uchar_t num_of_data,uchar_t CrcData)
{
  uchar_t crc;
  crc = crc8_compute(p, num_of_data);// calculates 8-Bit checksum
  if(crc != CrcData) 
   {   
    return 1;           
   }
return 0;
}

/*****SHT30温度数据处理*******/
void sht30_data_process(void)
{
	uchar_t temporary[3],i;           //用于暂时存放总线读出的温湿度值
    uint16_t  Data_convert,Data_convert1;           //用于数据转换	
    uchar_t crc_result;             //用于CRC校验结果存放，为判断数据准确性做准备
	
	read_sht30(read_sht_data,6);  //读出数据放入缓存数组等待处理>>T高八位>>T低八位>>温度T的CRC校验位>>H高八位>>H低八位>>湿度H的CRC校验位
	temporary[0]=read_sht_data[0];//温度数据高八位
    temporary[1]=read_sht_data[1];//温度数据低八位
    temporary[2]=read_sht_data[2];//温度数据CRC校验位
	
    crc_result=sht30_crc8_check(temporary,2,temporary[2]);	 //crc校验，crc校验要是不成功就返回1，
	                                                         //同时不会更新温度值
    if(crc_result==0)  
    {
    	Data_convert=(uint16_t)(temporary[0] << 8) | temporary[1];  //把2个8位数据拼接为一个16位的数据
    	//温度转换，将16位温度数据转化为10进制的温度数据，这里保留了一位小数，SHT30_temperature这是一个全局变量，
		//计算温度值（uchar强制转换，数据在超过八位范围后会丢失）
		//printf("\r\nTemp--data_convert:%d\r\n",Data_convert);
    	//SHT30_temperature = (uint16_t)((175.0 * (float)(0x7fff&Data_convert) / 65535.0 - 45.0) *10.0);  
		Data_convert1=Data_convert*17500/65535-4500;
    	//printf("\r\nTemp--data_convert1:%d \r\n",Data_convert1);
	
    	SHT30_Temp[0]=Data_convert1/1000+'0';
		SHT30_Temp[1]=Data_convert1%1000/100+'0';
    	SHT30_Temp[2]='.';
		SHT30_Temp[3]=Data_convert1%100/10+'0';
		SHT30_Temp[4]=Data_convert1%10+'0';
		SHT30_Temp[5]='\0';

		SHT30_Temp1[0]=Data_convert1/1000+'0';
		SHT30_Temp1[1]=Data_convert1%1000/100+'0';
    	SHT30_Temp1[2]='.';
		SHT30_Temp1[3]=Data_convert1%100/10+'0';
		SHT30_Temp1[4]=Data_convert1%10+'0';

    	printf("\r\nTemp:%s \r\n",SHT30_Temp);
    }
	else if(crc_result==1)
	{
        printf("\r\nread temerature CRC error!\r\n");
	}

    temporary[0]=read_sht_data[3];//湿度数据高八位
    temporary[1]=read_sht_data[4];//湿度数据低八位
    temporary[2]=read_sht_data[5];//湿度数据CRC校验位
  	//crc校验
    crc_result=sht30_crc8_check(temporary,2,temporary[2]);   //crc校验，crc校验要是不成功就返回1，
	                                                         //同时不会更新湿度值
  	if(crc_result==0)
    {
    	Data_convert=(uint16_t)(temporary[0] << 8) | temporary[1];
    	//湿度转换，将16位湿度数据转化为10进制的湿度数据，这里保留了一位小数，SHT30_humidity这是一个全局变量，
		//计算湿度值（uchar强制转换，数据在超过八位范围后会丢失）	
    	//printf("\r\nHumi--data_convert:%d\r\n",Data_convert);
    	//SHT30_humidity = (uint16_t)((100.0 * (float)(0x7fff&Data_convert) / 65535.0) *10.0); 
       	Data_convert1=Data_convert*17500/65535-4500;	
    	//printf("\r\nHumi--data_convert1:%d \r\n",Data_convert1);

		SHT30_Humi[0]=Data_convert1/1000+'0';
		SHT30_Humi[1]=Data_convert1%1000/100+'0';
    	SHT30_Humi[2]='.';
		SHT30_Humi[3]=Data_convert1%100/10+'0';
		SHT30_Humi[4]=Data_convert1%10+'0';
		SHT30_Humi[5]='\0';

		SHT30_Humi1[0]=Data_convert1/1000+'0';
		SHT30_Humi1[1]=Data_convert1%1000/100+'0';
    	SHT30_Humi1[2]='.';
		SHT30_Humi1[3]=Data_convert1%100/10+'0';
		SHT30_Humi1[4]=Data_convert1%10+'0';

    	printf("\r\nHumi:%s %\r\n",SHT30_Humi);

    }	
	else if(crc_result==1)
	{
        printf("\r\nread humidity CRC error!\r\n");
	}
}
