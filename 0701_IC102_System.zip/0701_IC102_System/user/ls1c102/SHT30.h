#ifndef __SHT30_H
#define __SHT30_H

#include "ls1x.h"


extern uchar_t read_sht_data[7];


extern	uint16_t SHT30_temperature;
extern	uint16_t SHT30_humidity;


void sht30_init(void);
void read_sht30(uchar_t *p,uchar_t number);
void sht30_data_process(void);
int  crc8_compute(uchar_t *check_data, uchar_t num_of_data);
int  sht30_crc8_check(uchar_t *p,uchar_t num_of_data,uchar_t CrcData);


#endif 

