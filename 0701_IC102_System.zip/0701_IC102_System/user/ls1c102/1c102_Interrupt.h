#ifndef _1C102_INTERRUPT_H_
#define _1C102_INTERRUPT_H_

#define MAX_receive 128

#endif